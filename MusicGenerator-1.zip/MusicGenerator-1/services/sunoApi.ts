import Constants from "expo-constants";

const API_KEY = Constants.expoConfig?.extra?.SUNO_API_KEY || process.env.SUNO_API_KEY;
const BASE_URL = "https://api.sunoapi.org";

export interface GenerateRequest {
  prompt: string;
  model?: string;
  instrumental?: boolean;
}

export interface Track {
  id: string;
  title: string;
  modelName?: string;
  duration?: number;
  audioUrl?: string;
  streamAudioUrl?: string;
  imageUrl?: string;
  createdAt?: string;
}

export interface GenerationResult {
  taskId: string;
  tracks: Track[];
}

export interface HistoryEntry {
  timestamp: string;
  prompt: string;
  model: string;
  instrumental: boolean;
  taskId: string;
  tracks: Track[];
}

async function headers() {
  return {
    Authorization: `Bearer ${API_KEY}`,
    "Content-Type": "application/json",
  };
}

export async function generateMusic(
  request: GenerateRequest
): Promise<GenerationResult> {
  if (!API_KEY) {
    throw new Error("Suno API key is not configured");
  }

  const payload = {
    prompt: request.prompt,
    model: request.model || "V4_5",
    customMode: false,
    instrumental: Boolean(request.instrumental),
    callBackUrl: "https://example.com/callback",
  };

  const response = await fetch(`${BASE_URL}/api/v1/generate`, {
    method: "POST",
    headers: await headers(),
    body: JSON.stringify(payload),
  });

  const data = await response.json();

  if (data.code !== 200) {
    throw new Error(data.msg || "Failed to generate music");
  }

  const taskId = data.data.taskId;
  const tracks = await waitForResult(taskId);

  return {
    taskId,
    tracks,
  };
}

async function waitForResult(taskId: string): Promise<Track[]> {
  const startTime = Date.now();
  const timeout = 300000;

  while (true) {
    const response = await fetch(
      `${BASE_URL}/api/v1/generate/record-info?taskId=${taskId}`,
      {
        method: "GET",
        headers: await headers(),
      }
    );

    const data = await response.json();

    if (data.code !== 200) {
      throw new Error(data.msg || "Failed to check generation status");
    }

    const info = data.data;
    const status = info.status;

    if (status === "SUCCESS") {
      return info.response.sunoData.map((track: any) => ({
        id: track.id || String(Math.random()),
        title: track.title || "Untitled Track",
        modelName: track.modelName,
        duration: track.duration,
        audioUrl: track.audioUrl,
        streamAudioUrl: track.streamAudioUrl,
        imageUrl: track.imageUrl,
        createdAt: new Date().toISOString(),
      }));
    }

    if (
      status === "CREATE_TASK_FAILED" ||
      status === "GENERATE_AUDIO_FAILED" ||
      status === "CALLBACK_EXCEPTION" ||
      status === "SENSITIVE_WORD_ERROR"
    ) {
      throw new Error(`Generation failed: ${status}`);
    }

    if (Date.now() - startTime > timeout) {
      throw new Error("Generation timeout - please try again");
    }

    await new Promise((resolve) => setTimeout(resolve, 5000));
  }
}
