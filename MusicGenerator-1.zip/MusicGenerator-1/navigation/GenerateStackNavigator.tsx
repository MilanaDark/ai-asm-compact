import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import GenerateScreen from "@/screens/GenerateScreen";
import { HeaderTitle } from "@/components/HeaderTitle";
import { useTheme } from "@/hooks/useTheme";
import { getCommonScreenOptions } from "@/navigation/screenOptions";

export type GenerateStackParamList = {
  Generate: undefined;
};

const Stack = createNativeStackNavigator<GenerateStackParamList>();

export default function GenerateStackNavigator() {
  const { theme, isDark } = useTheme();

  return (
    <Stack.Navigator
      screenOptions={{
        ...getCommonScreenOptions({ theme, isDark }),
      }}
    >
      <Stack.Screen
        name="Generate"
        component={GenerateScreen}
        options={{
          headerTitle: () => <HeaderTitle title="Suno Music Generator" />,
        }}
      />
    </Stack.Navigator>
  );
}
