import React, { createContext, useContext, useState, ReactNode } from "react";
import { Track, HistoryEntry } from "@/services/sunoApi";

interface MusicContextType {
  library: Track[];
  history: HistoryEntry[];
  addToLibrary: (tracks: Track[]) => void;
  addToHistory: (entry: HistoryEntry) => void;
  removeFromLibrary: (trackId: string) => void;
}

const MusicContext = createContext<MusicContextType | undefined>(undefined);

export function MusicProvider({ children }: { children: ReactNode }) {
  const [library, setLibrary] = useState<Track[]>([]);
  const [history, setHistory] = useState<HistoryEntry[]>([]);

  const addToLibrary = (tracks: Track[]) => {
    setLibrary((prev) => [...tracks, ...prev]);
  };

  const addToHistory = (entry: HistoryEntry) => {
    setHistory((prev) => [entry, ...prev].slice(0, 20));
  };

  const removeFromLibrary = (trackId: string) => {
    setLibrary((prev) => prev.filter((track) => track.id !== trackId));
  };

  return (
    <MusicContext.Provider
      value={{
        library,
        history,
        addToLibrary,
        addToHistory,
        removeFromLibrary,
      }}
    >
      {children}
    </MusicContext.Provider>
  );
}

export function useMusicContext() {
  const context = useContext(MusicContext);
  if (!context) {
    throw new Error("useMusicContext must be used within a MusicProvider");
  }
  return context;
}
