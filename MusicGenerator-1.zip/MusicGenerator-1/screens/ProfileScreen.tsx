import { useState } from "react";
import { StyleSheet, View, Image, Pressable, Switch, TextInput } from "react-native";
import { Feather } from "@expo/vector-icons";
import { ScreenScrollView } from "@/components/ScreenScrollView";
import { ThemedText } from "@/components/ThemedText";
import { Card } from "@/components/Card";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, Typography } from "@/constants/theme";
import { useColorScheme } from "@/hooks/useColorScheme";
import { useMusicContext } from "@/contexts/MusicContext";

export default function ProfileScreen() {
  const { theme, isDark } = useTheme();
  const colorScheme = useColorScheme();
  const { library } = useMusicContext();

  const [displayName, setDisplayName] = useState("Music Lover");
  const [isEditing, setIsEditing] = useState(false);

  const getStorageSize = () => {
    const tracksCount = library.length;
    const estimatedSize = tracksCount * 3.5;
    return `${estimatedSize.toFixed(1)} MB (${tracksCount} tracks)`;
  };

  return (
    <ScreenScrollView>
      <View style={styles.header}>
        <Image
          source={require("@/assets/illustrations/user_avatar_preset.png")}
          style={styles.avatar}
          resizeMode="cover"
        />
        <View style={styles.nameContainer}>
          {isEditing ? (
            <TextInput
              style={[
                styles.nameInput,
                {
                  backgroundColor: theme.backgroundDefault,
                  color: theme.text,
                  borderColor: theme.border,
                },
              ]}
              value={displayName}
              onChangeText={setDisplayName}
              onBlur={() => setIsEditing(false)}
              autoFocus
            />
          ) : (
            <Pressable onPress={() => setIsEditing(true)}>
              <ThemedText type="heading2" style={styles.displayName}>
                {displayName}
              </ThemedText>
            </Pressable>
          )}
          <Pressable
            onPress={() => setIsEditing(!isEditing)}
            style={styles.editButton}
          >
            <Feather
              name={isEditing ? "check" : "edit-2"}
              size={16}
              color={theme.primary}
            />
          </Pressable>
        </View>
      </View>

      <ThemedText type="heading2" style={styles.sectionTitle}>
        Appearance
      </ThemedText>
      <Card style={styles.settingCard}>
        <View style={styles.settingRow}>
          <View style={styles.settingInfo}>
            <Feather name="moon" size={20} color={theme.text} />
            <ThemedText style={styles.settingLabel}>
              Theme: {isDark ? "Dark" : "Light"}
            </ThemedText>
          </View>
          <ThemedText type="caption" style={styles.settingValue}>
            System
          </ThemedText>
        </View>
      </Card>

      <ThemedText type="heading2" style={styles.sectionTitle}>
        Storage
      </ThemedText>
      <Card style={styles.settingCard}>
        <View style={styles.settingRow}>
          <View style={styles.settingInfo}>
            <Feather name="hard-drive" size={20} color={theme.text} />
            <ThemedText style={styles.settingLabel}>Library Size</ThemedText>
          </View>
          <ThemedText type="caption" style={styles.settingValue}>
            {getStorageSize()}
          </ThemedText>
        </View>
      </Card>

      <ThemedText type="heading2" style={styles.sectionTitle}>
        About
      </ThemedText>
      <Card style={styles.settingCard}>
        <View style={styles.settingRow}>
          <View style={styles.settingInfo}>
            <Feather name="info" size={20} color={theme.text} />
            <ThemedText style={styles.settingLabel}>App Version</ThemedText>
          </View>
          <ThemedText type="caption" style={styles.settingValue}>
            1.0.0
          </ThemedText>
        </View>
      </Card>

      <Card style={styles.settingCard}>
        <Pressable
          style={styles.settingRow}
          onPress={() => console.log("Open privacy policy")}
        >
          <View style={styles.settingInfo}>
            <Feather name="shield" size={20} color={theme.text} />
            <ThemedText style={styles.settingLabel}>Privacy Policy</ThemedText>
          </View>
          <Feather name="chevron-right" size={20} color={theme.textSecondary} />
        </Pressable>
      </Card>

      <Card style={styles.settingCard}>
        <Pressable
          style={styles.settingRow}
          onPress={() => console.log("Open terms")}
        >
          <View style={styles.settingInfo}>
            <Feather name="file-text" size={20} color={theme.text} />
            <ThemedText style={styles.settingLabel}>Terms of Service</ThemedText>
          </View>
          <Feather name="chevron-right" size={20} color={theme.textSecondary} />
        </Pressable>
      </Card>
    </ScreenScrollView>
  );
}

const styles = StyleSheet.create({
  header: {
    alignItems: "center",
    marginBottom: Spacing["3xl"],
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: BorderRadius.full,
    marginBottom: Spacing.md,
  },
  nameContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
  },
  displayName: {
    textAlign: "center",
  },
  nameInput: {
    fontSize: Typography.heading2.fontSize,
    fontWeight: Typography.heading2.fontWeight,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.sm,
    borderWidth: 1,
    minWidth: 200,
    textAlign: "center",
  },
  editButton: {
    padding: Spacing.xs,
  },
  sectionTitle: {
    marginTop: Spacing["2xl"],
    marginBottom: Spacing.md,
  },
  settingCard: {
    marginBottom: Spacing.md,
  },
  settingRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  settingInfo: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.md,
    flex: 1,
  },
  settingLabel: {
    flex: 1,
  },
  settingValue: {
    opacity: 0.6,
  },
});
