import { View, StyleSheet } from "react-native";
import { ThemedText } from "@/components/ThemedText";
import { useScreenInsets } from "@/hooks/useScreenInsets";
import { Spacing } from "@/constants/theme";

export default function SettingsScreen() {
  const insets = useScreenInsets();

  return (
    <View
      style={[
        styles.container,
        {
          paddingTop: insets.paddingTop,
          paddingBottom: insets.paddingBottom,
        },
      ]}
    >
      <ThemedText>Settings Screen Placeholder</ThemedText>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: Spacing.lg,
  },
});
