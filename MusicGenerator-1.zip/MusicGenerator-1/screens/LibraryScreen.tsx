import { View, StyleSheet, FlatList, Pressable, Image } from "react-native";
import { Feather } from "@expo/vector-icons";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { Card } from "@/components/Card";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, Typography } from "@/constants/theme";
import { useMusicContext } from "@/contexts/MusicContext";
import { Track } from "@/services/sunoApi";

export default function LibraryScreen() {
  const { theme } = useTheme();
  const { library, removeFromLibrary } = useMusicContext();

  const renderTrack = ({ item }: { item: Track }) => (
    <Card style={styles.trackItem}>
      <View style={styles.trackContent}>
        <Image
          source={require("@/assets/illustrations/track_placeholder_waveform_art.png")}
          style={styles.thumbnail}
          resizeMode="cover"
        />
        <View style={styles.trackInfo}>
          <ThemedText style={styles.trackTitle} numberOfLines={1}>
            {item.title}
          </ThemedText>
          <ThemedText type="caption" style={styles.trackMeta}>
            {item.modelName || "Suno"}
            {item.duration ? ` • ${Math.round(item.duration)}s` : ""}
          </ThemedText>
          {item.createdAt ? (
            <ThemedText type="small" style={styles.timestamp}>
              {new Date(item.createdAt).toLocaleDateString()}
            </ThemedText>
          ) : null}
        </View>
        <View style={styles.actions}>
          <Pressable
            style={({ pressed }) => [
              styles.actionButton,
              { opacity: pressed ? 0.6 : 1 },
            ]}
            onPress={() => console.log("Play track:", item.id)}
          >
            <Feather name="play-circle" size={24} color={theme.primary} />
          </Pressable>
          <Pressable
            style={({ pressed }) => [
              styles.actionButton,
              { opacity: pressed ? 0.6 : 1 },
            ]}
            onPress={() => removeFromLibrary(item.id)}
          >
            <Feather name="trash-2" size={20} color={theme.error} />
          </Pressable>
        </View>
      </View>
    </Card>
  );

  const renderEmptyState = () => (
    <View style={styles.emptyState}>
      <Image
        source={require("@/assets/illustrations/library_empty_state_illustration.png")}
        style={styles.emptyIllustration}
        resizeMode="contain"
      />
      <ThemedText type="heading2" style={styles.emptyTitle}>
        No tracks yet
      </ThemedText>
      <ThemedText type="body" style={styles.emptyMessage}>
        Generate your first music track to see it appear here
      </ThemedText>
    </View>
  );

  return (
    <ThemedView style={styles.container}>
      <FlatList
        data={library}
        renderItem={renderTrack}
        keyExtractor={(item) => item.id}
        contentContainerStyle={[
          styles.listContent,
          library.length === 0 && styles.emptyListContent,
        ]}
        ListEmptyComponent={renderEmptyState}
        showsVerticalScrollIndicator={false}
      />
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  listContent: {
    padding: Spacing.lg,
    paddingBottom: Spacing["5xl"],
  },
  emptyListContent: {
    flex: 1,
    justifyContent: "center",
  },
  trackItem: {
    marginBottom: Spacing.md,
  },
  trackContent: {
    flexDirection: "row",
    alignItems: "center",
  },
  thumbnail: {
    width: 60,
    height: 60,
    borderRadius: BorderRadius.xs,
    marginRight: Spacing.md,
  },
  trackInfo: {
    flex: 1,
  },
  trackTitle: {
    fontWeight: "600",
    marginBottom: Spacing.xs,
  },
  trackMeta: {
    opacity: 0.7,
    marginBottom: Spacing.xs,
  },
  timestamp: {
    opacity: 0.5,
  },
  actions: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.md,
  },
  actionButton: {
    padding: Spacing.xs,
  },
  emptyState: {
    alignItems: "center",
    paddingHorizontal: Spacing["2xl"],
  },
  emptyIllustration: {
    width: 200,
    height: 200,
    marginBottom: Spacing["2xl"],
    opacity: 0.8,
  },
  emptyTitle: {
    marginBottom: Spacing.md,
    textAlign: "center",
  },
  emptyMessage: {
    textAlign: "center",
    opacity: 0.7,
  },
});
