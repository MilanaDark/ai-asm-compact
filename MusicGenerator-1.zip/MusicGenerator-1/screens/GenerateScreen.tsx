import { useState } from "react";
import {
  View,
  StyleSheet,
  TextInput,
  Switch,
  ActivityIndicator,
  Pressable,
  Image,
  ScrollView,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { ScreenKeyboardAwareScrollView } from "@/components/ScreenKeyboardAwareScrollView";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { Card } from "@/components/Card";
import { Button } from "@/components/Button";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, Typography } from "@/constants/theme";
import { generateMusic, Track, HistoryEntry } from "@/services/sunoApi";
import { useMusicContext } from "@/contexts/MusicContext";

const SelectOption = ({
  value,
  label,
  selected,
  onPress,
  theme,
}: {
  value: string;
  label: string;
  selected: boolean;
  onPress: () => void;
  theme: any;
}) => (
  <Pressable
    onPress={onPress}
    style={[
      styles.optionButton,
      {
        backgroundColor: selected ? theme.primary : theme.backgroundDefault,
        borderColor: selected ? theme.primary : theme.border,
      },
    ]}
  >
    <ThemedText
      style={[
        styles.optionText,
        { color: selected ? theme.buttonText : theme.text },
      ]}
    >
      {label}
    </ThemedText>
  </Pressable>
);

export default function GenerateScreen() {
  const { theme, isDark } = useTheme();
  const { addToLibrary, addToHistory } = useMusicContext();

  const [prompt, setPrompt] = useState("");
  const [model, setModel] = useState("V4_5");
  const [genre, setGenre] = useState("");
  const [language, setLanguage] = useState("");
  const [instrumental, setInstrumental] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [statusMessage, setStatusMessage] = useState("");
  const [generatedTracks, setGeneratedTracks] = useState<Track[]>([]);

  const modelOptions = [
    { value: "V4_5", label: "V4.5 (Latest)" },
    { value: "V4", label: "V4" },
    { value: "V3_5", label: "V3.5" },
  ];

  const genreOptions = [
    { value: "", label: "None" },
    { value: "epic orchestral", label: "Epic Orchestral" },
    { value: "pop", label: "Pop" },
    { value: "rock", label: "Rock" },
    { value: "electronic", label: "Electronic" },
    { value: "lofi chill", label: "Lo-fi / Chill" },
  ];

  const languageOptions = [
    { value: "", label: "Auto" },
    { value: "English", label: "English" },
    { value: "Ukrainian", label: "Ukrainian" },
    { value: "Polish", label: "Polish" },
    { value: "Spanish", label: "Spanish" },
  ];

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      setStatusMessage("Please enter a prompt");
      return;
    }

    setIsGenerating(true);
    setStatusMessage("Generating... this may take 1-2 minutes");
    setGeneratedTracks([]);

    try {
      let finalPrompt = prompt.trim();

      if (genre) {
        finalPrompt = `${genre} style, ${finalPrompt}`;
      }

      if (language) {
        finalPrompt = `${finalPrompt} (lyrics language: ${language})`;
      }

      const result = await generateMusic({
        prompt: finalPrompt,
        model,
        instrumental,
      });

      setGeneratedTracks(result.tracks);
      setStatusMessage("Generated successfully!");

      addToLibrary(result.tracks);

      const historyEntry: HistoryEntry = {
        timestamp: new Date().toISOString(),
        prompt: finalPrompt,
        model,
        instrumental,
        taskId: result.taskId,
        tracks: result.tracks,
      };
      addToHistory(historyEntry);
    } catch (error) {
      setStatusMessage(
        `Error: ${error instanceof Error ? error.message : "Failed to generate music"}`
      );
    } finally {
      setIsGenerating(false);
    }
  };

  const inputStyle = [
    styles.input,
    {
      backgroundColor: theme.backgroundDefault,
      color: theme.text,
      borderColor: theme.border,
    },
  ];

  return (
    <ScreenKeyboardAwareScrollView>
      <View style={styles.section}>
        <ThemedText style={styles.label}>Music Prompt</ThemedText>
        <TextInput
          style={[inputStyle, styles.textArea]}
          value={prompt}
          onChangeText={setPrompt}
          placeholder="Describe the music you want to create..."
          placeholderTextColor={theme.textSecondary}
          multiline
          numberOfLines={4}
          maxLength={500}
          textAlignVertical="top"
        />
        <ThemedText type="caption" style={styles.charCount}>
          {prompt.length}/500
        </ThemedText>
      </View>

      <Card style={styles.configCard}>
        <ThemedText style={styles.cardTitle}>Model</ThemedText>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.optionsContainer}
        >
          {modelOptions.map((option) => (
            <SelectOption
              key={option.value}
              value={option.value}
              label={option.label}
              selected={model === option.value}
              onPress={() => setModel(option.value)}
              theme={theme}
            />
          ))}
        </ScrollView>
      </Card>

      <Card style={styles.configCard}>
        <ThemedText style={styles.cardTitle}>Genre (Optional)</ThemedText>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.optionsContainer}
        >
          {genreOptions.map((option) => (
            <SelectOption
              key={option.value}
              value={option.value}
              label={option.label}
              selected={genre === option.value}
              onPress={() => setGenre(option.value)}
              theme={theme}
            />
          ))}
        </ScrollView>
      </Card>

      <Card style={styles.configCard}>
        <ThemedText style={styles.cardTitle}>Lyrics Language</ThemedText>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.optionsContainer}
        >
          {languageOptions.map((option) => (
            <SelectOption
              key={option.value}
              value={option.value}
              label={option.label}
              selected={language === option.value}
              onPress={() => setLanguage(option.value)}
              theme={theme}
            />
          ))}
        </ScrollView>
      </Card>

      <Card style={styles.configCard}>
        <View style={styles.switchRow}>
          <ThemedText style={styles.cardTitle}>Instrumental Only</ThemedText>
          <Switch
            value={instrumental}
            onValueChange={setInstrumental}
            trackColor={{ false: theme.backgroundSecondary, true: theme.primary }}
            thumbColor={theme.backgroundRoot}
          />
        </View>
      </Card>

      <Button
        onPress={handleGenerate}
        disabled={isGenerating}
        style={styles.generateButton}
      >
        {isGenerating ? (
          <View style={styles.buttonContent}>
            <ActivityIndicator color={theme.buttonText} size="small" />
            <ThemedText style={[styles.buttonText, { color: theme.buttonText }]}>
              Generating...
            </ThemedText>
          </View>
        ) : (
          <View style={styles.buttonContent}>
            <Feather name="music" size={20} color={theme.buttonText} />
            <ThemedText style={[styles.buttonText, { color: theme.buttonText }]}>
              Generate Music
            </ThemedText>
          </View>
        )}
      </Button>

      {statusMessage ? (
        <ThemedText style={styles.statusMessage}>{statusMessage}</ThemedText>
      ) : null}

      {generatedTracks.length > 0 ? (
        <View style={styles.resultsSection}>
          <ThemedText type="heading2" style={styles.resultsTitle}>
            Generated Tracks
          </ThemedText>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            style={styles.tracksScroll}
          >
            {generatedTracks.map((track) => (
              <Card key={track.id} style={styles.trackCard}>
                <Image
                  source={require("@/assets/illustrations/track_placeholder_waveform_art.png")}
                  style={styles.trackArt}
                  resizeMode="cover"
                />
                <ThemedText style={styles.trackTitle} numberOfLines={2}>
                  {track.title}
                </ThemedText>
                <ThemedText type="caption" style={styles.trackMeta}>
                  {track.modelName || model}
                  {track.duration ? ` • ${Math.round(track.duration)}s` : ""}
                </ThemedText>
                <Pressable
                  style={({ pressed }) => [
                    styles.playButton,
                    { backgroundColor: theme.primary, opacity: pressed ? 0.8 : 1 },
                  ]}
                  onPress={() => console.log("Play track:", track.id)}
                >
                  <Feather name="play" size={16} color={theme.buttonText} />
                </Pressable>
              </Card>
            ))}
          </ScrollView>
        </View>
      ) : null}
    </ScreenKeyboardAwareScrollView>
  );
}

const styles = StyleSheet.create({
  section: {
    marginBottom: Spacing.lg,
  },
  label: {
    marginBottom: Spacing.sm,
    fontWeight: "600",
  },
  input: {
    borderWidth: 1,
    borderRadius: BorderRadius.sm,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
    fontSize: Typography.body.fontSize,
  },
  textArea: {
    minHeight: 100,
  },
  charCount: {
    textAlign: "right",
    marginTop: Spacing.xs,
    opacity: 0.6,
  },
  configCard: {
    marginBottom: Spacing.md,
  },
  cardTitle: {
    fontWeight: "600",
    marginBottom: Spacing.sm,
  },
  switchRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  optionsContainer: {
    gap: Spacing.sm,
  },
  optionButton: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
  },
  optionText: {
    fontSize: Typography.caption.fontSize,
    fontWeight: "500",
  },
  generateButton: {
    marginTop: Spacing.md,
    marginBottom: Spacing.lg,
  },
  buttonContent: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: Spacing.sm,
  },
  buttonText: {
    fontSize: Typography.body.fontSize,
    fontWeight: "600",
  },
  statusMessage: {
    textAlign: "center",
    marginBottom: Spacing.lg,
    opacity: 0.8,
  },
  resultsSection: {
    marginTop: Spacing.lg,
    marginBottom: Spacing["3xl"],
  },
  resultsTitle: {
    marginBottom: Spacing.lg,
  },
  tracksScroll: {
    marginHorizontal: -Spacing.lg,
    paddingHorizontal: Spacing.lg,
  },
  trackCard: {
    width: 180,
    marginRight: Spacing.md,
  },
  trackArt: {
    width: "100%",
    height: 180,
    borderRadius: BorderRadius.sm,
    marginBottom: Spacing.sm,
  },
  trackTitle: {
    fontWeight: "600",
    marginBottom: Spacing.xs,
  },
  trackMeta: {
    opacity: 0.6,
    marginBottom: Spacing.sm,
  },
  playButton: {
    width: 32,
    height: 32,
    borderRadius: BorderRadius.full,
    alignItems: "center",
    justifyContent: "center",
  },
});
