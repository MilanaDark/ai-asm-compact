# Suno Music Generator Mobile App - Design Guidelines

## Architecture Decisions

### Authentication
**No Authentication Required** - This is a utility app for music generation with local session storage.

**Profile/Settings Screen Required:**
- User avatar (generate 1 preset avatar: musical note or waveform icon)
- Display name field for personalization
- App preferences:
  - Theme toggle (light/dark mode)
  - Audio quality preference
  - Auto-save generated tracks toggle
  - Notification preferences for generation completion

### Navigation Structure
**Root Navigation:** Tab Navigation (3 tabs)

**Tabs:**
1. **Generate** (Home) - Primary music creation interface
2. **Library** (Center) - Saved/generated tracks collection
3. **Profile** - Settings and preferences

**Navigation Stack:**
- Generate Tab: Generate Screen → Track Detail Modal
- Library Tab: Library Screen → Track Detail Modal
- Profile Tab: Profile Screen → Settings Screen

## Screen Specifications

### 1. Generate Screen (Home Tab)
**Purpose:** Create new music from text prompts

**Layout:**
- **Header:** Transparent, default navigation
  - Title: "Generate Music"
  - No additional buttons
- **Main Content:** ScrollView with keyboard-aware behavior
  - Safe area insets: top = headerHeight + Spacing.xl, bottom = tabBarHeight + Spacing.xl
- **Floating Elements:** None

**Components:**
1. **Prompt Input Section:**
   - Multi-line text input (4-5 lines, auto-expanding)
   - Placeholder: "Describe the music you want to create..."
   - Character counter (optional, max 500 characters)
   - Subtle border, rounded corners (BorderRadius.lg)

2. **Configuration Cards:**
   - **Model Selection Card:**
     - Title: "Model"
     - Picker/Select: V4_5 (default), V4, V3_5
     - Info icon with tooltip explaining model differences
   - **Genre Selection Card:**
     - Title: "Genre (optional)"
     - Picker: None, Epic Orchestral, Pop, Rock, Electronic, Lo-fi/Chill
   - **Language Selection Card:**
     - Title: "Lyrics Language"
     - Picker: Auto, English, Ukrainian, Polish, Spanish
   - **Instrumental Toggle:**
     - Switch component with label "Instrumental Only"

3. **Generate Button:**
   - Full-width primary button
   - Height: 56px
   - Position: Below configuration cards
   - Loading state: spinner + "Generating... (1-2 min)"
   - Success state: brief checkmark animation

4. **Status Indicator:**
   - Text below button showing generation progress
   - Progress bar when actively generating

5. **Results Section:**
   - Appears after successful generation
   - Horizontal scrollable cards showing generated tracks
   - Each card: cover art placeholder, title, duration, play button

### 2. Track Detail Modal
**Purpose:** Full playback and download interface

**Layout:**
- **Header:** Modal header with close button (X)
- **Main Content:** Non-scrollable, centered layout
  - Safe area insets: top = insets.top + Spacing.xl, bottom = insets.bottom + Spacing.xl

**Components:**
1. Large album art placeholder (gradient or waveform visualization)
2. Track title (bold, Typography.heading2)
3. Metadata: Model name, duration, timestamp
4. Native audio player controls:
   - Play/pause (large center button)
   - Scrubber/timeline with timestamps
   - Volume control
5. Action buttons:
   - Save to library (heart icon)
   - Share (share icon)
   - Download (download icon)

### 3. Library Screen (Tab 2)
**Purpose:** Browse and replay saved/generated tracks

**Layout:**
- **Header:** Default navigation
  - Title: "My Library"
  - Right button: Search icon
- **Main Content:** FlatList
  - Safe area insets: top = Spacing.xl, bottom = tabBarHeight + Spacing.xl
- **Empty State:** Illustration + "No tracks yet" message

**Components:**
1. **Track List Items:**
   - Thumbnail (square, 60x60px)
   - Title + subtitle (model/genre)
   - Timestamp (small, muted text)
   - Mini play button overlay
   - Swipe actions: Delete (red), Share (blue)
2. **Search Bar** (when search icon tapped):
   - Animated slide-down
   - Filter by model, genre, date

### 4. Profile Screen (Tab 3)
**Purpose:** User preferences and app settings

**Layout:**
- **Header:** Transparent, default navigation
  - Title: "Profile"
- **Main Content:** ScrollView
  - Safe area insets: top = headerHeight + Spacing.xl, bottom = tabBarHeight + Spacing.xl

**Components:**
1. **Profile Header:**
   - Centered avatar (80x80px, tappable to select preset)
   - Display name (editable, Typography.heading2)
2. **Settings Sections (Grouped Lists):**
   - **Playback:**
     - Audio quality (High/Medium/Low)
     - Auto-save tracks toggle
   - **Appearance:**
     - Theme (System/Light/Dark)
   - **Notifications:**
     - Generation complete alerts toggle
   - **About:**
     - Version number
     - Terms & Privacy links
   - **Storage:**
     - Clear cache button
     - Storage used indicator

## Design System

### Color Palette
**Primary:** Purple gradient (#8B5CF6 → #7C3AED) - represents creativity and music
**Secondary:** Blue accent (#3B82F6) - for info/metadata
**Success:** Green (#10B981) - generation complete
**Error:** Red (#EF4444) - failed generation
**Background:**
- Light mode: #FFFFFF, #F9FAFB (secondary)
- Dark mode: #0F172A, #1E293B (secondary)
**Text:**
- Primary: #1F2937 (light) / #F9FAFB (dark)
- Secondary: #6B7280 (light) / #94A3B8 (dark)

### Typography
- **Heading1:** 28px, bold, tight line-height
- **Heading2:** 24px, semibold
- **Body:** 16px, regular, 1.5 line-height
- **Caption:** 14px, regular, muted color
- **Small:** 12px, regular

### Component Styles
1. **Cards:**
   - Background: surface color (white/dark surface)
   - Border radius: 16px
   - Padding: Spacing.lg (16px)
   - Shadow: subtle on light mode, none on dark
   
2. **Buttons:**
   - Primary: Purple gradient, white text, 56px height, BorderRadius.xl
   - Secondary: Transparent, border, colored text
   - Pressed state: opacity 0.8, subtle scale (0.98)

3. **Inputs:**
   - Border: 1px, color: border-muted
   - Focused: border-primary, subtle glow
   - BorderRadius: 12px
   - Padding: Spacing.md

4. **Floating Action Button (if needed):**
   - Shadow specifications:
     - shadowOffset: {width: 0, height: 2}
     - shadowOpacity: 0.10
     - shadowRadius: 2
   - Size: 56x56px, circular

### Visual Feedback
- **Touchables:** Opacity 0.6 on press OR subtle scale (0.98)
- **Loading states:** Skeleton screens for track loading
- **Animations:**
  - Generate button: pulse during generation
  - Track cards: slide-in from bottom on appearance
  - Tab transitions: smooth fade

### Icons
- Use Feather icons from @expo/vector-icons
- Primary icons: Music, Play, Pause, Download, Share, Settings, Search, Heart
- Size: 24px (default), 20px (small), 32px (large)

## Critical Assets

### Required Generated Assets:
1. **User Avatar Preset (1):**
   - Musical note icon or waveform symbol
   - Style: Minimalist, matches app aesthetic
   - Size: 200x200px, exportable

2. **Empty State Illustrations (2):**
   - Library empty state: Headphones with musical notes
   - No results: Broken music note or search with X
   - Style: Line art, purple accent color

3. **Track Placeholder Art:**
   - Generic waveform gradient background
   - Reusable for all generated tracks
   - Size: 300x300px square

### DO NOT Include:
- Emoji anywhere in the UI
- Custom icons for standard actions (use Feather icons)
- Decorative images unrelated to music/audio

## Accessibility Requirements
- Minimum touch target: 44x44px
- Color contrast ratio: 4.5:1 for text
- Audio player: VoiceOver labels for all controls
- Form inputs: Clear labels and placeholders
- Error states: Color + icon + text (not color alone)
- Focus indicators for keyboard navigation